package com.ranweir.fluxangel.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.LongState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.ranweir.fluxangel.LyricLine
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Position that keeps moving smoothly between the player's (slow) position updates. */
@Composable
fun rememberSmoothPos(raw: () -> Long, playing: () -> Boolean): LongState {
    val out = remember { mutableLongStateOf(0L) }
    val base = remember { mutableLongStateOf(0L) }
    val stamp = remember { mutableLongStateOf(0L) }
    val r = raw()
    LaunchedEffect(r) { base.longValue = r; stamp.longValue = System.nanoTime(); out.longValue = r }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameMillis {
                out.longValue = if (playing()) base.longValue + (System.nanoTime() - stamp.longValue) / 1_000_000L else base.longValue
            }
        }
    }
    return out
}

/**
 * Styles: 0 = Style 1 (letters fill, soft blur), 1 = Style 2 (letters fill and lift up),
 * 2 = Boring (word by word, no blur), 3 = Plain (whole line lights up).
 * speed 0 = slower .. 1 = faster.
 */
@Composable
fun LyricsView(
    lines: List<LyricLine>, style: Int, speed: Float, pos: LongState, fontSize: TextUnit,
    topFrac: Float, padBottom: Dp, modifier: Modifier = Modifier, onSeek: (Long) -> Unit = {}
) {
    val m = 2f - 1.5f * speed
    val active by remember(lines) {
        derivedStateOf {
            val p = pos.longValue + 250
            var lo = 0; var hi = lines.lastIndex; var ans = -1
            while (lo <= hi) { val mid = (lo + hi) / 2; if (lines[mid].timeMs <= p) { ans = mid; lo = mid + 1 } else hi = mid - 1 }
            ans
        }
    }
    val state = rememberLazyListState()
    LaunchedEffect(active, speed) {
        if (active < 0) return@LaunchedEffect
        val vp = state.layoutInfo.viewportSize.height
        val want = (vp * topFrac)
        val item = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == active }
        if (item != null) state.animateScrollBy(item.offset - want, tween((520 * m).toInt(), easing = FastOutSlowInEasing))
        else state.animateScrollToItem(active, -want.toInt())
    }
    LazyColumn(
        state = state,
        modifier = modifier.fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(0f to Color.Transparent, 0.1f to Color.Black, 0.72f to Color.Black, 1f to Color.Transparent),
                    blendMode = BlendMode.DstIn
                )
            },
        contentPadding = PaddingValues(top = 16.dp, bottom = padBottom)
    ) {
        itemsIndexed(lines) { i, line ->
            val on = i == active
            val dist = abs(i - active).coerceAtMost(4)
            val a by animateFloatAsState(if (on) 1f else if (i < active) 0.35f else 0.45f, tween((350 * m).toInt()), label = "a")
            val sc by animateFloatAsState(if (on || style >= 2) 1f else 0.94f, spring(0.8f, Spring.StiffnessLow / m), label = "s")
            val bl by animateFloatAsState(if (on || style >= 2) 0f else dist * 1.4f, tween((350 * m).toInt()), label = "b")
            val txt = line.text.ifBlank { "♪" }
            val base = TextStyle(fontSize = fontSize, lineHeight = fontSize * 1.3f, fontWeight = FontWeight.Bold)
            val mod = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                .blur(bl.dp, BlurredEdgeTreatment.Unbounded)
                .graphicsLayer { scaleX = sc; scaleY = sc; transformOrigin = TransformOrigin(0f, 0.5f) }
                .pointerInput(line) { detectTapGestures { onSeek(line.timeMs) } }
            if (!on || style == 3) {
                Text(txt, style = base, color = Color.White.copy(alpha = if (on) 1f else a), modifier = mod)
            } else {
                val nextT = lines.getOrNull(i + 1)?.timeMs ?: (line.timeMs + 4000)
                val dur = (nextT - line.timeMs).coerceIn(600L, 9000L)
                val fillDur = dur * (0.95f - 0.45f * speed)
                val prog = ((pos.longValue - line.timeMs) / fillDur).coerceIn(0f, 1f)
                val b = prog * (txt.length + 1)
                val dim = Color.White.copy(alpha = 0.4f)
                val wordStart = if (style == 2) IntArray(txt.length).also { ws ->
                    var st = 0
                    for (c in txt.indices) { if (c > 0 && txt[c - 1] == ' ') st = c; ws[c] = st }
                } else null
                val styled = buildAnnotatedString {
                    for (c in txt.indices) {
                        val cov = if (wordStart != null) (if (wordStart[c] <= b) 1f else 0f) else (b - c).coerceIn(0f, 1f)
                        val w = (b - c) / 3f
                        val lift = if (style == 1 && w in 0f..1f) sin(PI.toFloat() * w) * 0.28f else 0f
                        withStyle(SpanStyle(color = lerp(dim, Color.White, cov), baselineShift = BaselineShift(lift))) { append(txt[c]) }
                    }
                }
                Text(styled, style = base, modifier = mod)
            }
        }
    }
}
