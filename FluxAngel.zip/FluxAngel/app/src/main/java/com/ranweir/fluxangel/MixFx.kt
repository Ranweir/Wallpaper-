package com.ranweir.fluxangel

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * "Mix" transitions between songs: each song fades out at its end and the next one fades in, so songs flow into each other
 * instead of cutting. Auto-flow picks the fade length from the song's own length; Manual uses the length set in Settings.
 *
 * Note: this is a fade-out / fade-in (a smooth "dip"), not an overlap where two songs play at the same time.
 */
object MixFx {
    var enabled by mutableStateOf(false); private set
    var auto by mutableStateOf(true); private set
    var seconds by mutableIntStateOf(6); private set      // manual fade length, 1..12 s

    // plain copies read by the player's ticker
    @Volatile internal var on = false
    @Volatile internal var autoF = true
    @Volatile internal var secMs = 6000L

    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("flux", Context.MODE_PRIVATE)
        prefs = p
        enabled = p.getBoolean("mix_on", false)
        auto = p.getBoolean("mix_auto", true)
        seconds = p.getInt("mix_sec", 6).coerceIn(1, 12)
        sync()
    }

    private fun sync() { on = enabled; autoF = auto; secMs = seconds * 1000L }

    fun updateEnabled(v: Boolean) { enabled = v; prefs?.edit()?.putBoolean("mix_on", v)?.apply(); sync() }
    fun updateAuto(v: Boolean) { auto = v; prefs?.edit()?.putBoolean("mix_auto", v)?.apply(); sync() }
    fun updateSeconds(v: Int) { seconds = v.coerceIn(1, 12); prefs?.edit()?.putInt("mix_sec", seconds)?.apply(); sync() }

    /** Fade length (ms) for a song of this length. Never more than a third of the song. */
    internal fun fadeMs(songMs: Long): Long {
        val want = if (autoF) (songMs * 0.03).toLong().coerceIn(2500L, 7000L) else secMs
        return want.coerceAtMost(songMs / 3).coerceAtLeast(300L)
    }
}
