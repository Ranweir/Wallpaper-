package com.ranweir.fluxangel

import android.app.Application
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.ranweir.fluxangel.ui.AccentColor
import com.ranweir.fluxangel.ui.BarStyle
import com.ranweir.fluxangel.ui.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

@androidx.compose.runtime.Stable
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("flux", Context.MODE_PRIVATE)

    var themeMode by mutableStateOf(
        runCatching { ThemeMode.valueOf(prefs.getString("theme", "DARK")!!) }
            .getOrDefault(ThemeMode.DARK)
    )
        private set

    var barStyle by mutableStateOf(
        runCatching { BarStyle.valueOf(prefs.getString("bar_style", "BLUR")!!) }
            .getOrDefault(BarStyle.BLUR)
    )
        private set

    var accent by mutableStateOf(
        runCatching { AccentColor.valueOf(prefs.getString("accent", "CYAN")!!) }.getOrDefault(AccentColor.CYAN)
    )
        private set
    var downloadQuality by mutableStateOf(
        runCatching { AudioQuality.valueOf(prefs.getString("dl_quality", "HIGH")!!) }.getOrDefault(AudioQuality.HIGH)
    )
        private set
    var streamQuality by mutableStateOf(
        runCatching { AudioQuality.valueOf(prefs.getString("stream_quality", "HIGH")!!) }.getOrDefault(AudioQuality.HIGH)
    )
        private set
    var wifiOnly by mutableStateOf(prefs.getBoolean("wifi_only", false))
        private set
    var autoDownload by mutableStateOf(prefs.getBoolean("auto_download", false))
        private set

    /** Now Playing: size of the cover cards (1.0 = default) and strength of the blurred background (0..100). */
    var cardScale by mutableFloatStateOf(prefs.getFloat("card_scale", 1.1f).coerceIn(0.8f, 1.3f))
        private set
    var bgBlur by mutableIntStateOf(prefs.getInt("bg_blur", 0).coerceIn(0, 100))
        private set
    /** 0.5 = slow, 1 = default, 2 = quick: speed of the now-playing open / close animation. */
    var playerAnimSpeed by mutableFloatStateOf(prefs.getFloat("anim_speed", 1f).coerceIn(0.5f, 2f))
    fun updatePlayerAnimSpeed(v: Float) { playerAnimSpeed = v.coerceIn(0.5f, 2f); prefs.edit().putFloat("anim_speed", playerAnimSpeed).apply() }
    fun updateCardScale(v: Float) { cardScale = v.coerceIn(0.8f, 1.3f); prefs.edit().putFloat("card_scale", cardScale).apply() }
    // blurred strip at the bottom of the screen (behind the navigation bar)
    var navBlurOn by mutableStateOf(prefs.getBoolean("nav_blur_on", true))
        private set
    var navBlurStrength by mutableIntStateOf(prefs.getInt("nav_blur_str", 0).coerceIn(0, 100))
        private set
    var navFade by mutableIntStateOf(prefs.getInt("nav_fade", 59).coerceIn(0, 100))
        private set
    var navBlurHeight by mutableIntStateOf(prefs.getInt("nav_blur_h", 86).coerceIn(80, 280))
        private set
    fun updateNavBlurOn(v: Boolean) { navBlurOn = v; prefs.edit().putBoolean("nav_blur_on", v).apply() }
    fun updateNavBlurStrength(v: Int) { navBlurStrength = v.coerceIn(0, 100); prefs.edit().putInt("nav_blur_str", navBlurStrength).apply() }
    fun updateNavFade(v: Int) { navFade = v.coerceIn(0, 100); prefs.edit().putInt("nav_fade", navFade).apply() }
    fun updateNavBlurHeight(v: Int) { navBlurHeight = v.coerceIn(80, 280); prefs.edit().putInt("nav_blur_h", navBlurHeight).apply() }

    // blurred strip behind the status bar (top edge of the screen)
    var topBlurOn by mutableStateOf(prefs.getBoolean("top_blur_on", true))
        private set
    var topBlurStrength by mutableIntStateOf(prefs.getInt("top_blur_str", 40).coerceIn(0, 100))
        private set
    var topFade by mutableIntStateOf(prefs.getInt("top_fade", 25).coerceIn(0, 100))
        private set
    var topBlurHeight by mutableIntStateOf(prefs.getInt("top_blur_h", 44).coerceIn(20, 140))
        private set
    fun updateTopBlurOn(v: Boolean) { topBlurOn = v; prefs.edit().putBoolean("top_blur_on", v).apply() }
    fun updateTopBlurStrength(v: Int) { topBlurStrength = v.coerceIn(0, 100); prefs.edit().putInt("top_blur_str", topBlurStrength).apply() }
    fun updateTopFade(v: Int) { topFade = v.coerceIn(0, 100); prefs.edit().putInt("top_fade", topFade).apply() }
    fun updateTopBlurHeight(v: Int) { topBlurHeight = v.coerceIn(20, 140); prefs.edit().putInt("top_blur_h", topBlurHeight).apply() }

    fun updateBgBlur(v: Int) { bgBlur = v.coerceIn(0, 100); prefs.edit().putInt("bg_blur", bgBlur).apply() }

    var glassBlur by mutableStateOf(prefs.getBoolean("glass_blur", true))
        private set

    // ---- profile name: shown on Home as "Hi, <name>" (empty = the time-of-day greeting) ----
    var lyricsStyle by mutableIntStateOf(prefs.getInt("lyr_style", 0).coerceIn(0, 3))
    var lyricsSpeed by mutableFloatStateOf(prefs.getFloat("lyr_speed", 0.5f).coerceIn(0f, 1f))
    fun updateLyricsStyle(v: Int) { lyricsStyle = v.coerceIn(0, 3); prefs.edit().putInt("lyr_style", lyricsStyle).apply() }
    fun updateLyricsSpeed(v: Float) { lyricsSpeed = v.coerceIn(0f, 1f); prefs.edit().putFloat("lyr_speed", lyricsSpeed).apply() }
    var profileName by mutableStateOf(prefs.getString("profile_name", "") ?: "")
        private set
    fun updateProfileName(n: String) {
        profileName = n.take(30)
        prefs.edit().putString("profile_name", profileName).apply()
    }

    // ---- profile picture (stored as a small square JPEG in the app's private files) ----
    var profileVersion by mutableStateOf(prefs.getLong("profile_v", 0L))
        private set
    val profileFile: java.io.File get() = java.io.File(getApplication<Application>().filesDir, "profile.jpg")

    fun setProfilePhoto(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { saveProfile(uri) }.getOrDefault(false) }
            if (ok) {
                profileVersion = System.currentTimeMillis()
                prefs.edit().putLong("profile_v", profileVersion).apply()
            } else toast("Could not use that photo")
        }
    }

    fun clearProfilePhoto() {
        runCatching { profileFile.delete() }
        profileVersion = 0L
        prefs.edit().putLong("profile_v", 0L).apply()
    }

    // ---------- backup & restore ----------
    // One JSON file holding everything the user created: favorites, playlists, history and all settings, plus the profile
    // photo. Device-specific download bookkeeping (file ids / uris) is not included; songs can be downloaded again.
    private val backupSkipKeys = setOf("downloads", "pending", "pending_songs", "profile_v")

    fun createBackup(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val o = JSONObject().put("app", "FluxAngel").put("format", 1).put("created", System.currentTimeMillis())
                    val items = JSONObject()
                    for ((k, v) in prefs.all) {
                        if (k in backupSkipKeys || v == null) continue
                        val e = JSONObject()
                        when (v) {
                            is String -> e.put("t", "s").put("v", v)
                            is Boolean -> e.put("t", "b").put("v", v)
                            is Int -> e.put("t", "i").put("v", v)
                            is Long -> e.put("t", "l").put("v", v)
                            is Float -> e.put("t", "f").put("v", v.toDouble())
                            is Set<*> -> e.put("t", "set").put("v", JSONArray(v.map { it.toString() }))
                            else -> continue
                        }
                        items.put(k, e)
                    }
                    o.put("prefs", items)
                    if (profileFile.exists()) {
                        o.put("profile", android.util.Base64.encodeToString(profileFile.readBytes(), android.util.Base64.NO_WRAP))
                    }
                    val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt") ?: error("no stream")
                    out.use { it.write(o.toString().toByteArray(Charsets.UTF_8)) }
                }.onFailure { AppLog.add("BACKUP", "Backup failed", it) }.isSuccess
            }
            toast(if (ok) "Backup saved" else "Could not save the backup")
        }
    }

    /** Replaces favorites, playlists, history and settings with the backup, then restarts the app so everything reloads. */
    fun restoreBackup(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val text = getApplication<Application>().contentResolver.openInputStream(uri)
                        ?.use { it.readBytes().toString(Charsets.UTF_8) } ?: error("no stream")
                    val o = JSONObject(text)
                    require(o.optString("app") == "FluxAngel") { "not a Flux Angel backup" }
                    val items = o.getJSONObject("prefs")
                    val e = prefs.edit()
                    for (k in prefs.all.keys) if (k !in backupSkipKeys) e.remove(k)
                    for (k in items.keys()) {
                        if (k in backupSkipKeys) continue
                        val ent = items.getJSONObject(k)
                        when (ent.getString("t")) {
                            "s" -> e.putString(k, ent.getString("v"))
                            "b" -> e.putBoolean(k, ent.getBoolean("v"))
                            "i" -> e.putInt(k, ent.getInt("v"))
                            "l" -> e.putLong(k, ent.getLong("v"))
                            "f" -> e.putFloat(k, ent.getDouble("v").toFloat())
                            "set" -> {
                                val a = ent.getJSONArray("v")
                                e.putStringSet(k, (0 until a.length()).map { i -> a.getString(i) }.toSet())
                            }
                        }
                    }
                    val photo = o.optString("profile")
                    if (photo.isNotEmpty()) {
                        profileFile.writeBytes(android.util.Base64.decode(photo, android.util.Base64.DEFAULT))
                        e.putLong("profile_v", System.currentTimeMillis())
                    } else {
                        runCatching { profileFile.delete() }
                        e.putLong("profile_v", 0L)
                    }
                    check(e.commit())
                }.onFailure { AppLog.add("BACKUP", "Restore failed", it) }.isSuccess
            }
            if (!ok) { toast("That file is not a valid Flux Angel backup"); return@launch }
            toast("Backup restored, restarting\u2026")
            delay(700)
            val ctx = getApplication<Application>()
            ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                ctx.startActivity(it)
            }
            android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    /** Decodes the picked image (down-sampled), fixes rotation, centre-crops to a square and saves 512x512. */
    private fun saveProfile(uri: Uri): Boolean {
        val cr = getApplication<Application>().contentResolver
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
        val src = cr.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
            ?: return false
        val rotation = cr.openInputStream(uri)?.use { s ->
            when (android.media.ExifInterface(s).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
            }
        } ?: 0f
        val side = minOf(src.width, src.height)
        val matrix = android.graphics.Matrix().apply { postRotate(rotation) }
        val square = android.graphics.Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side, matrix, true)
        val out = android.graphics.Bitmap.createScaledBitmap(square, 512, 512, true)
        profileFile.outputStream().use { out.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
        return true
    }

    // ---- search / home data ----
    var query by mutableStateOf("")
    var results by mutableStateOf<List<Song>>(emptyList()); private set
    var trending by mutableStateOf<List<Song>>(emptyList()); private set
    /** Songs picked from what the user listens to (their most played / saved artists); shown in Explore before they type. */
    var forYou by mutableStateOf<List<Song>>(emptyList()); private set
    private var searchJob: kotlinx.coroutines.Job? = null
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    // ---- library data (saved on device) ----
    var history by mutableStateOf(loadSongs("history")); private set
    var favorites by mutableStateOf(loadSongs("favorites")); private set
    var playlists by mutableStateOf(loadPlaylists()); private set
    /** Songs saved offline on the device (shown as "Downloads" in Library). */
    var downloads by mutableStateOf(loadDownloads()); private set

    // ---- player state ----
    var currentMeta by mutableStateOf<MediaMetadata?>(null); private set
    var currentId by mutableStateOf<String?>(null); private set
    private val retriedIds = HashSet<String>()
    var isPlaying by mutableStateOf(false); private set
    var buffering by mutableStateOf(false); private set
    var position by mutableStateOf(0L); private set
    var duration by mutableStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableStateOf(Player.REPEAT_MODE_OFF); private set

    private var controller: MediaController? = null
    /** Songs in the player, in the same order as the player's media items. */
    var queue by mutableStateOf<List<Song>>(emptyList()); private set
    var currentIndex by mutableStateOf(0); private set

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { this@MainViewModel.isPlaying = isPlaying }
        override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) { currentMeta = mediaMetadata }
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { shuffle = shuffleModeEnabled }
        override fun onRepeatModeChanged(mode: Int) { repeatMode = mode }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            currentId = mediaItem?.mediaId
            mediaItem?.mediaId?.let { retriedIds.remove(it) }
            controller?.let { currentIndex = it.currentMediaItemIndex }
            position = 0L
            queue.firstOrNull { it.url == mediaItem?.mediaId }?.let { addHistory(it) }
        }
        override fun onPlayerError(error: PlaybackException) {
            val id = currentId
            val httpFail = error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
            // expired / refused stream link (HTTP 403 ...): drop the cached link and silently retry once with a fresh one
            if (id != null && httpFail && retriedIds.add(id)) {
                AppLog.add("PLAYBACK", "Retrying with fresh stream link (${error.errorCodeName}, song: $id)", error)
                YouTubeRepo.invalidate(id)
                controller?.let { c -> c.seekTo(c.currentMediaItemIndex, c.currentPosition); c.prepare(); c.play() }
                return
            }
            this@MainViewModel.error = "Playback error: ${error.cause?.message ?: error.message}"
            AppLog.add("PLAYBACK", "Playback error ${error.errorCodeName} (song: ${id ?: "?"})", error)
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            currentMeta = c.mediaMetadata
            currentId = c.currentMediaItem?.mediaId
            currentIndex = c.currentMediaItemIndex
            isPlaying = c.isPlaying
            shuffle = c.shuffleModeEnabled
            repeatMode = c.repeatMode
        }, MoreExecutors.directExecutor())

        YouTubeRepo.streamQuality = streamQuality
        registerDownloadReceiver()
        syncDownloads()
        autoDownloadMissing()

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let {
                    position = it.currentPosition.coerceAtLeast(0L)
                    duration = it.duration.coerceAtLeast(0L)
                }
            }
        }
        viewModelScope.launch {
            try {
                trending = withContext(Dispatchers.IO) { YouTubeRepo.search("trending songs") }
                if (results.isEmpty()) results = trending
            } catch (e: Exception) {
                error = "Could not load songs: ${e.message}"
                AppLog.add("NETWORK", "Could not load trending songs", e)
            }
            // then the songs matching the user's taste (silent if it fails: trending stays as the fallback)
            runCatching { loadForYou() }.onSuccess { list ->
                forYou = list
                if (query.isBlank() && list.isNotEmpty()) results = list
            }
        }
    }

    /** Top artists from history, favorites and playlists -> a mixed list of their songs. */
    private suspend fun loadForYou(): List<Song> {
        val weight = HashMap<String, Int>()
        fun count(songs: List<Song>, w: Int) = songs.forEach { s ->
            val a = s.artist.removeSuffix(" - Topic").trim()
            if (a.isNotBlank() && a != "This phone" && a != "Unknown") weight[a] = (weight[a] ?: 0) + w
        }
        count(history, 1); count(favorites, 3); count(playlists.flatMap { it.songs }, 1)
        val top = weight.entries.sortedByDescending { it.value }.take(4).map { it.key }
        if (top.isEmpty()) return emptyList()
        val lists = coroutineScope {
            top.map { a -> async(Dispatchers.IO) { runCatching { YouTubeRepo.search("$a songs") }.getOrDefault(emptyList()) } }
                .map { it.await() }
        }
        val seen = HashSet<String>()
        val mixed = ArrayList<Song>()
        var i = 0
        while (mixed.size < 30 && lists.any { i < it.size }) {   // take turns between the artists
            lists.forEach { l -> l.getOrNull(i)?.let { if (seen.add(it.url)) mixed.add(it) } }
            i++
        }
        return mixed
    }

    /** Called on every key press in the search box: searches by itself shortly after typing stops. */
    fun onQueryChange(text: String) {
        query = text
        searchJob?.cancel()
        if (text.isBlank()) {
            loading = false; error = null
            results = forYou.ifEmpty { trending }
            return
        }
        searchJob = viewModelScope.launch {
            delay(450)
            runSearch(text)
        }
    }

    // ---------- search ----------
    fun search(q: String) {
        if (q.isBlank()) return
        query = q
        searchJob?.cancel()
        searchJob = viewModelScope.launch { runSearch(q) }
    }

    private suspend fun runSearch(q: String) {
        loading = true
        error = null
        try {
            results = withContext(Dispatchers.IO) { YouTubeRepo.search(q.trim()) }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "Search failed: ${e.message}"
            AppLog.add("NETWORK", "Search failed for \"$q\"", e)
        }
        loading = false
    }

    // ---------- play anything, straight away ----------
    /** Starts an artist's songs right away (no restrictions: any song, repeat, unlimited skips). */
    fun playArtist(name: String) {
        val a = name.removeSuffix(" - Topic").trim()
        if (a.isBlank()) return
        toast("Playing $a…")
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { YouTubeRepo.search("$a songs") }
                if (list.isEmpty()) toast("Nothing found for $a") else play(list, 0)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                AppLog.add("NETWORK", "Could not play artist $a", e)
                toast("Could not load $a: ${e.message}")
            }
        }
    }

    /** Stops the music completely and empties the player (the mini bar goes away with it). */
    fun stopPlayback() {
        controller?.let { it.stop(); it.clearMediaItems() }
        queue = emptyList(); currentIndex = 0
        currentId = null; currentMeta = null
        isPlaying = false; position = 0L; duration = 0L
    }

    fun shufflePlay(songs: List<Song>) { if (songs.isNotEmpty()) play(songs.shuffled(), 0) }

    // ---------- playback ----------
    fun play(songs: List<Song>, index: Int) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        queue = songs
        currentIndex = index.coerceIn(0, songs.lastIndex)
        error = null
        c.setMediaItems(songs.map { it.toMediaItem(downloadUri(it.url)) }, index.coerceIn(0, songs.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    /** Insert right after the current track (or start playing if nothing is queued). */
    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) { play(listOf(song), 0); return }
        val at = (c.currentMediaItemIndex + 1).coerceAtMost(c.mediaItemCount)
        c.addMediaItem(at, song.toMediaItem(downloadUri(song.url)))
        queue = queue.toMutableList().also { it.add(at.coerceAtMost(it.size), song) }
        toast("Will play next")
    }
    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) { play(listOf(song), 0); return }
        c.addMediaItem(song.toMediaItem(downloadUri(song.url)))
        queue = queue + song
        toast("Added to queue")
    }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }
    /** Jump to a song in the current queue (used when swiping the cover carousel). */
    fun skipTo(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount && index != c.currentMediaItemIndex) { c.seekToDefaultPosition(index); c.play() }
    }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun dismissError() { error = null }

    fun currentSong(): Song? {
        val id = currentId ?: return null
        queue.firstOrNull { it.url == id }?.let { return it }
        val m = currentMeta ?: return null
        return Song(id, m.title?.toString() ?: "", m.artist?.toString() ?: "", m.artworkUri?.toString() ?: "", duration / 1000)
    }

    // ---------- history ----------
    private fun addHistory(song: Song) {
        history = (listOf(song) + history.filterNot { it.url == song.url }).take(50)
        saveSongs("history", history)
    }
    fun clearHistory() { history = emptyList(); saveSongs("history", history) }

    // ---------- favorites & playlists ----------
    fun isFavorite(url: String) = favorites.any { it.url == url }
    fun toggleFavorite(song: Song) {
        val adding = !isFavorite(song.url)
        favorites = if (!adding) favorites.filterNot { it.url == song.url } else listOf(song) + favorites
        saveSongs("favorites", favorites)
        if (adding && autoDownload) download(song, quiet = true)
    }
    fun createPlaylist(name: String) {
        playlists = playlists + Playlist(name, emptyList())
        savePlaylists()
    }
    fun deletePlaylist(index: Int) {
        playlists = playlists.filterIndexed { i, _ -> i != index }
        savePlaylists()
    }
    fun togglePlaylistSong(index: Int, song: Song) {
        if (autoDownload && playlists.getOrNull(index)?.songs?.none { it.url == song.url } == true) download(song, quiet = true)
        playlists = playlists.mapIndexed { i, p ->
            if (i != index) p
            else if (p.songs.any { it.url == song.url }) p.copy(songs = p.songs.filterNot { it.url == song.url })
            else p.copy(songs = p.songs + song)
        }
        savePlaylists()
    }

    // ---------- Spotify / file import ----------
    class ImportProgress(
        val name: String, val done: Int, val total: Int, val added: Int, val failed: Int,
        val finished: Boolean = false, val error: String? = null, val note: String? = null
    )
    var importState by mutableStateOf<ImportProgress?>(null); private set
    private var importJob: kotlinx.coroutines.Job? = null

    fun importRunning() = importState?.let { !it.finished && it.error == null } == true
    fun dismissImport() { if (!importRunning()) importState = null }
    fun cancelImport() { importJob?.cancel(); importJob = null; importState = null }

    fun importSpotify(link: String) = startImport("Spotify playlist") {
        withContext(Dispatchers.IO) { SpotifyImporter.fetchPlaylist(link) }
            .let { Triple(it.name, it.tracks, if (it.maybeTruncated)
                "Spotify only shared the first ${it.tracks.size} songs of this playlist. For the rest, export it as CSV (exportify.net) and use \"Import from file\"." else null) }
    }

    fun importFromFile(uri: Uri) = startImport("Imported playlist") {
        withContext(Dispatchers.IO) {
            val cr = getApplication<Application>().contentResolver
            val fileName = runCatching {
                cr.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                }
            }.getOrNull()?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: "Imported playlist"
            val text = cr.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw java.io.IOException("Could not open the file")
            val tracks = SpotifyImporter.parseFile(text)
            if (tracks.isEmpty()) throw java.io.IOException("No songs found in this file")
            Triple(fileName, tracks, null as String?)
        }
    }

    /** [load] reads the song list (name, songs, optional note); then every song is matched on YouTube and added in order. */
    private fun startImport(placeholder: String, load: suspend () -> Triple<String, List<SpotifyTrack>, String?>) {
        if (importRunning()) return
        importJob = viewModelScope.launch {
            importState = ImportProgress(placeholder, 0, 0, 0, 0)
            try {
                val (rawName, tracks, note) = load()
                // own playlist, name made unique so progress updates always hit the right one
                var name = rawName.trim().ifBlank { placeholder }
                var n = 2
                while (playlists.any { it.name == name }) name = "${rawName.trim()} ($n)".also { n++ }
                playlists = playlists + Playlist(name, emptyList())
                savePlaylists()

                var added = 0; var failed = 0; var done = 0
                val seen = HashSet<String>()
                val pending = ArrayList<Song>()
                fun flush() {
                    if (pending.isEmpty()) return
                    val batch = pending.toList(); pending.clear()
                    playlists = playlists.map { if (it.name == name) it.copy(songs = it.songs + batch) else it }
                    savePlaylists()
                }
                importState = ImportProgress(name, 0, tracks.size, 0, 0, note = note)
                for (chunk in tracks.chunked(3)) {
                    val found = coroutineScope {
                        chunk.map { t ->
                            async(Dispatchers.IO) {
                                runCatching { SpotifyImporter.matchToYouTube(t) }.getOrNull()
                            }
                        }.map { it.await() }
                    }
                    for (song in found) {
                        done++
                        if (song == null) failed++
                        else if (seen.add(song.url)) { added++; pending += song }
                    }
                    if (pending.size >= 6) flush()
                    importState = ImportProgress(name, done, tracks.size, added, failed, note = note)
                }
                flush()
                importState = ImportProgress(name, done, tracks.size, added, failed, finished = true, note = note)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                AppLog.add("IMPORT", "Import failed", e)
                importState = ImportProgress(placeholder, 0, 0, 0, 0, error = e.message ?: "Import failed")
            }
        }
    }

    fun savedSongs(): List<Song> = (favorites + playlists.flatMap { it.songs } + downloads.map { it.song } + localSongs).distinctBy { it.url }

    // ---------- songs imported from this phone ----------
    /** Audio files the user added from the phone; [Song.url] is the file's content:// address, played directly (no streaming). */
    var localSongs by mutableStateOf(loadSongs("local_songs")); private set

    fun importLocal(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val read = withContext(Dispatchers.IO) { uris.mapNotNull { readLocalSong(it) } }
            val known = localSongs.map { it.url }.toSet()
            val fresh = read.filter { it.url !in known }.distinctBy { it.url }
            if (fresh.isNotEmpty()) { localSongs = localSongs + fresh; saveSongs("local_songs", localSongs) }
            toast(
                when {
                    fresh.isEmpty() && read.isNotEmpty() -> "Already in your library"
                    fresh.isEmpty() -> "Could not read those files (see Settings, Error & crash logs)"
                    else -> "Added ${fresh.size} song${if (fresh.size == 1) "" else "s"} from this phone"
                }
            )
        }
    }

    fun removeLocal(song: Song) {
        localSongs = localSongs.filterNot { it.url == song.url }
        saveSongs("local_songs", localSongs)
        runCatching { if (song.thumb.startsWith("file:")) java.io.File(Uri.parse(song.thumb).path!!).delete() }
        toast("Removed from the app (the file on your phone is untouched)")
    }

    private fun readLocalSong(uri: Uri): Song? {
        val ctx = getApplication<Application>()
        return try {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = runCatching {
                ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull()?.substringBeforeLast('.')?.takeIf { it.isNotBlank() }
            val mmr = android.media.MediaMetadataRetriever()
            try {
                mmr.setDataSource(ctx, uri)
                val title = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
                    ?: name ?: "Unknown song"
                val artist = (mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST))
                    ?.takeIf { it.isNotBlank() } ?: "This phone"
                val dur = (mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000
                var thumb = ""
                mmr.embeddedPicture?.let { bytes ->
                    val f = java.io.File(ctx.filesDir, "local_art/${uri.toString().hashCode()}.img")
                    f.parentFile?.mkdirs()
                    f.writeBytes(bytes)
                    thumb = Uri.fromFile(f).toString()
                }
                Song(uri.toString(), title, artist, thumb, dur)
            } finally { runCatching { mmr.release() } }
        } catch (e: Exception) {
            AppLog.add("ERROR", "Could not read local song: $uri", e)
            null
        }
    }

    private fun loadSongs(key: String): List<Song> = runCatching {
        val arr = JSONArray(prefs.getString(key, "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it).toSong() }
    }.getOrDefault(emptyList())

    private fun saveSongs(key: String, list: List<Song>) {
        prefs.edit().putString(key, JSONArray(list.map { it.toJson() }).toString()).apply()
    }

    private fun loadPlaylists(): List<Playlist> = runCatching {
        val arr = JSONArray(prefs.getString("playlists", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val s = o.getJSONArray("s")
            Playlist(o.getString("n"), (0 until s.length()).map { j -> s.getJSONObject(j).toSong() })
        }
    }.getOrDefault(emptyList())

    private fun savePlaylists() {
        val arr = JSONArray(playlists.map { p ->
            JSONObject().put("n", p.name).put("s", JSONArray(p.songs.map { it.toJson() }))
        })
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    // ---------- download (best quality, audio only) ----------
    private fun toast(msg: String) {
        Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_LONG).show()
    }

    private val dm get() = getApplication<Application>().getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun isDownloaded(url: String) = downloads.any { it.song.url == url }
    private fun downloadUri(url: String): String? = downloads.firstOrNull { it.song.url == url }?.uri

    fun download(song: Song, quiet: Boolean = false) {
        if (!song.url.startsWith("http")) { if (!quiet) toast("This song is already on your phone"); return }
        if (isDownloaded(song.url)) { if (!quiet) toast("Already downloaded"); return }
        if (pendingDownloads().containsValue(song.url)) { if (!quiet) toast("Already downloading"); return }
        if (!quiet) toast("Preparing download…")
        viewModelScope.launch {
            try {
                val r = withContext(Dispatchers.IO) { YouTubeRepo.resolve(song.url, forDownload = true, quality = downloadQuality) }
                val safe = song.title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(100).ifBlank { "song" }
                val req = DownloadManager.Request(Uri.parse(r.url))
                    .setTitle(song.title)
                    .setDescription("Flux Angel")
                    .setMimeType(r.mime)
                    .addRequestHeader("User-Agent", YouTubeRepo.userAgentFor(r.url))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .apply { if (wifiOnly) setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI) }
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "Flux Angel/$safe.${r.ext}")
                val id = dm.enqueue(req)
                // remember id -> song so it still lands in Library even if the app is closed meanwhile
                savePending(pendingDownloads() + (id to song.url), song)
                if (!quiet) toast("Downloading (${r.kbps} kbps): ${song.title}")
            } catch (e: Exception) {
                AppLog.add("DOWNLOAD", "Download failed: ${song.title} (${song.url})", e)
                if (!quiet) toast("Download failed: ${e.message}")
            }
        }
    }

    fun removeDownload(song: Song) {
        val d = downloads.firstOrNull { it.song.url == song.url } ?: return
        runCatching { dm.remove(d.id) }
        downloads = downloads.filterNot { it.song.url == song.url }
        saveDownloads()
        toast("Download removed")
    }

    // pending: downloadId -> song url (songs themselves kept in "pending_songs")
    private fun pendingDownloads(): Map<Long, String> = runCatching {
        val o = JSONObject(prefs.getString("pending", "{}")!!)
        o.keys().asSequence().associate { it.toLong() to o.getString(it) }
    }.getOrDefault(emptyMap())

    private fun savePending(map: Map<Long, String>, newSong: Song? = null) {
        val o = JSONObject(); map.forEach { (k, v) -> o.put(k.toString(), v) }
        val e = prefs.edit().putString("pending", o.toString())
        if (newSong != null) {
            val songs = loadSongs("pending_songs").filterNot { it.url == newSong.url } + newSong
            e.putString("pending_songs", JSONArray(songs.map { it.toJson() }).toString())
        }
        e.apply()
    }

    private fun registerDownloadReceiver() {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) { syncDownloads() }
        }
        ContextCompat.registerReceiver(
            getApplication<Application>(), receiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED
        )
    }

    /** Moves finished downloads into [downloads] and drops ones the user deleted. */
    private fun syncDownloads() {
        val pending = pendingDownloads().toMutableMap()
        val songs = loadSongs("pending_songs")
        var list = downloads
        for ((id, url) in pending.toMap()) {
            val c = dm.query(DownloadManager.Query().setFilterById(id))
            c.use {
                if (!it.moveToFirst()) { pending.remove(id); return@use }   // cancelled / removed
                when (it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        val song = songs.firstOrNull { s -> s.url == url }
                        val uri = dm.getUriForDownloadedFile(id)
                        if (song != null && uri != null) {
                            list = listOf(DownloadedSong(song, uri.toString(), id)) + list.filterNot { d -> d.song.url == url }
                        }
                        pending.remove(id)
                    }
                    DownloadManager.STATUS_FAILED -> pending.remove(id)
                    else -> {}
                }
                Unit
            }
        }
        // drop downloads whose entry was removed from the system Downloads app
        list = list.filter { d ->
            dm.query(DownloadManager.Query().setFilterById(d.id)).use { c -> c.moveToFirst() }
        }
        val remaining = songs.filter { s -> pending.containsValue(s.url) }
        prefs.edit().putString("pending_songs", JSONArray(remaining.map { it.toJson() }).toString()).apply()
        savePending(pending)
        if (list != downloads) { downloads = list; saveDownloads() }
    }

    private fun loadDownloads(): List<DownloadedSong> = runCatching {
        val arr = JSONArray(prefs.getString("downloads", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            DownloadedSong(o.getJSONObject("song").toSong(), o.getString("uri"), o.getLong("id"))
        }
    }.getOrDefault(emptyList())

    private fun saveDownloads() {
        val arr = JSONArray(downloads.map {
            JSONObject().put("song", it.song.toJson()).put("uri", it.uri).put("id", it.id)
        })
        prefs.edit().putString("downloads", arr.toString()).apply()
    }

    // ---------- settings ----------
    fun updateGlassBlur(on: Boolean) {
        glassBlur = on
        prefs.edit().putBoolean("glass_blur", on).apply()
    }

    fun updateAccent(a: AccentColor) { accent = a; prefs.edit().putString("accent", a.name).apply() }
    fun updateDownloadQuality(q: AudioQuality) { downloadQuality = q; prefs.edit().putString("dl_quality", q.name).apply() }
    fun updateStreamQuality(q: AudioQuality) {
        streamQuality = q; YouTubeRepo.streamQuality = q
        prefs.edit().putString("stream_quality", q.name).apply()
    }
    fun updateWifiOnly(v: Boolean) { wifiOnly = v; prefs.edit().putBoolean("wifi_only", v).apply() }
    fun updateAutoDownload(v: Boolean) {
        autoDownload = v; prefs.edit().putBoolean("auto_download", v).apply()
        if (v) autoDownloadMissing()
    }

    /** Downloads favourites/playlist songs that are not on the device yet (max 20 per run). */
    fun autoDownloadMissing() {
        if (!autoDownload) return
        val pending = pendingDownloads().values.toSet()
        (favorites + playlists.flatMap { it.songs }).distinctBy { it.url }
            .filterNot { isDownloaded(it.url) || it.url in pending }
            .take(20).forEach { download(it, quiet = true) }
    }

    fun updateBarStyle(s: BarStyle) {
        barStyle = s
        prefs.edit().putString("bar_style", s.name).apply()
    }

    fun setTheme(mode: ThemeMode) {
        themeMode = mode
        prefs.edit().putString("theme", mode.name).apply()
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
