# Flux Angel
Online YouTube music player with background / lock-screen playback.
Developer & credits: **Ranweir** · Telegram: https://t.me/ranweirsinventory

Build: push to GitHub → Actions → "Build APK" → download `FluxAngel-apk` artifact.

Spotify import: Library > import icon. Paste a public playlist link, or import a CSV/text file (e.g. from exportify.net) for private / 100+ song playlists.
