# Wallpaper App (Download only)

1. `lib/main.dart` me `baseUrl` me USERNAME aur REPO apne GitHub ke hisaab se badlo.
2. Is poore folder ko GitHub repo (branch `main`) me upload karo. Repo PUBLIC rakhna.
3. Images `wallpapers/` me daalo aur `wallpapers.json` me entry jodo.
4. Repo ke Actions tab me "Build APK" chalega. Khatam hone par run kholo -> Artifacts -> `wallpaper-apk` download karo, zip kholo, APK install karo.
