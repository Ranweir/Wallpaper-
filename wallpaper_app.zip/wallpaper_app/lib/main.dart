import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;

// ====== CHANGE ONLY THIS LINE ======
// Your GitHub username and repo name (branch: main)
const String baseUrl =
    'https://raw.githubusercontent.com/USERNAME/REPO/main/';
// =========================================

String base = baseUrl;
String resolve(String u) => u.startsWith('http') ? u : base + u;

class AppLog {
  static final List<String> _lines = [];
  static final Set<String> _seen = {};
  static void add(String level, String msg, {bool once = false}) {
    final key = '$level $msg';
    if (once && !_seen.add(key)) return;
    final t = DateTime.now().toIso8601String().substring(11, 19);
    _lines.add('[$t] $level: $msg');
    if (_lines.length > 300) _lines.removeAt(0);
  }
  static String get text =>
      _lines.isEmpty ? 'No log entries yet.' : _lines.join('\n\n');
  static void clear() {
    _lines.clear();
    _seen.clear();
  }
}

void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) => AppLog.add('FLUTTER_ERROR', '${d.exceptionAsString()}\n${d.stack}');
    AppLog.add('INFO', 'App started. baseUrl = $baseUrl');
    runApp(const WallApp());
  }, (e, st) => AppLog.add('UNCAUGHT', '$e\n$st'));
}

class WallApp extends StatelessWidget {
  const WallApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'My Wallpapers',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const HomePage(),
      );
}

class Wall {
  final String title, category, url, thumb;
  Wall.direct(this.title, this.category, this.url) : thumb = url;
  Wall(Map<String, dynamic> j)
      : title = j['title'] ?? '',
        category = j['category'] ?? '',
        url = resolve(j['url'] ?? ''),
        thumb = resolve(j['thumb'] ?? j['url'] ?? '');
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Wall> all = [];
  String cat = 'All', query = '';
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<http.Response> _get(String url) async {
    AppLog.add('INFO', 'GET $url');
    final r = await http.get(Uri.parse(url));
    AppLog.add('INFO', 'HTTP ${r.statusCode}, ${r.bodyBytes.length} bytes');
    return r;
  }

  bool _isImg(String n) =>
      RegExp(r'\.(jpe?g|png|webp)$', caseSensitive: false).hasMatch(n);

  Future<List<Wall>> _fromJson() async {
    final r = await _get('${base}wallpapers.json');
    if (r.statusCode != 200) throw 'HTTP ${r.statusCode}';
    final list = jsonDecode(utf8.decode(r.bodyBytes)) as List;
    return list.map((e) => Wall(e)).toList();
  }

  // Fallback: list images directly from the repo's wallpapers/ folder
  Future<List<Wall>> _fromFolder(String owner, String repo, String branch) async {
    final out = <Wall>[];
    Future<void> walk(String path, String category) async {
      final r = await _get(
          'https://api.github.com/repos/$owner/$repo/contents/$path?ref=$branch');
      if (r.statusCode != 200) {
        throw 'GitHub API HTTP ${r.statusCode} for /$path';
      }
      for (final f in jsonDecode(utf8.decode(r.bodyBytes)) as List) {
        final name = f['name'] as String;
        if (f['type'] == 'file' && _isImg(name)) {
          out.add(Wall.direct(name.replaceAll(RegExp(r'\.\w+$'), ''),
              category, f['download_url']));
        } else if (f['type'] == 'dir' && category.isEmpty) {
          await walk(f['path'], name);
        }
      }
    }

    await walk('wallpapers', '');
    return out;
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    final parts = Uri.parse(baseUrl).pathSegments;
    final owner = parts[0], repo = parts[1];
    var branch = parts[2];
    base = baseUrl;
    all = [];
    try {
      all = await _fromJson();
    } catch (e) {
      AppLog.add('WARN', 'wallpapers.json failed: $e. Trying fallbacks...');
      try {
        final r = await _get('https://api.github.com/repos/$owner/$repo');
        if (r.statusCode == 200) {
          final b = jsonDecode(utf8.decode(r.bodyBytes))['default_branch'];
          AppLog.add('INFO', 'Default branch = $b');
          if (b != branch) {
            branch = b;
            base = 'https://raw.githubusercontent.com/$owner/$repo/$branch/';
            try {
              all = await _fromJson();
            } catch (e2) {
              AppLog.add('WARN', 'wallpapers.json on $branch failed: $e2');
            }
          }
        } else {
          AppLog.add('WARN',
              'Repo not reachable via API (private repo or wrong name?)');
        }
        if (all.isEmpty) all = await _fromFolder(owner, repo, branch);
        if (all.isEmpty) throw 'No images found in wallpapers/ folder';
        AppLog.add('INFO', 'Loaded ${all.length} wallpapers via fallback');
      } catch (e3, st) {
        AppLog.add('ERROR', 'All methods failed: $e3\n$st');
        error = 'Could not load wallpapers.\n\n$e3\n\n'
            'Repo: $owner/$repo\n'
            'Check: repo is public, wallpapers.json or a wallpapers/ folder '
            'with images exists.\nSee the error log for details.';
      }
    }
    if (all.isNotEmpty) AppLog.add('INFO', 'Loaded ${all.length} wallpapers');
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final cats = ['All', ...{...all.map((w) => w.category).where((c) => c.isNotEmpty)}];
    final list = all
        .where((w) =>
            (cat == 'All' || w.category == cat) &&
            w.title.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('My Wallpapers'), actions: [
        IconButton(
          tooltip: 'Error log',
          icon: const Icon(Icons.bug_report_outlined),
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const LogPage())),
        ),
      ]),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(error!, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: load, child: const Text('Retry')),
                  TextButton(
                      onPressed: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => const LogPage())),
                      child: const Text('View error log')),
                ]))
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search…',
                        prefixIcon: const Icon(Icons.search),
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none),
                      ),
                      onChanged: (v) => setState(() => query = v),
                    ),
                  ),
                  SizedBox(
                    height: 52,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      children: cats
                          .map((c) => Padding(
                                padding: const EdgeInsets.all(6),
                                child: ChoiceChip(
                                  label: Text(c),
                                  selected: c == cat,
                                  onSelected: (_) => setState(() => cat = c),
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: load,
                      child: GridView.builder(
                        padding: const EdgeInsets.all(12),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10,
                                childAspectRatio: 9 / 16),
                        itemCount: list.length,
                        itemBuilder: (_, i) => GestureDetector(
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => PreviewPage(wall: list[i]))),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.network(list[i].thumb,
                                fit: BoxFit.cover,
                                errorBuilder: (_, err, ___) {
                                  AppLog.add('IMAGE_ERROR',
                                      '${list[i].thumb}\n$err',
                                      once: true);
                                  return const ColoredBox(
                                      color: Colors.black26,
                                      child: Icon(Icons.broken_image));
                                }),
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
    );
  }
}

class PreviewPage extends StatefulWidget {
  final Wall wall;
  const PreviewPage({super.key, required this.wall});
  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> {
  bool busy = false;

  Future<void> download() async {
    setState(() => busy = true);
    String msg;
    try {
      AppLog.add('INFO', 'Download: ${widget.wall.url}');
      if (!await Gal.hasAccess()) await Gal.requestAccess();
      final r = await http.get(Uri.parse(widget.wall.url));
      AppLog.add('INFO', 'Download response: HTTP ${r.statusCode}, ${r.bodyBytes.length} bytes');
      if (r.statusCode != 200) throw 'HTTP ${r.statusCode}';
      await Gal.putImageBytes(r.bodyBytes, album: 'Wallpapers');
      AppLog.add('INFO', 'Saved to gallery');
      msg = 'Saved to gallery (Wallpapers album)';
    } catch (e, st) {
      AppLog.add('ERROR', 'Download failed: $e\n$st');
      msg = 'Download failed: $e (see error log)';
    }
    if (!mounted) return;
    setState(() => busy = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: Text(widget.wall.title)),
        body: Column(children: [
          Expanded(
            child: InteractiveViewer(
              child: Center(
                  child: Image.network(widget.wall.url,
                      loadingBuilder: (_, c, p) => p == null
                          ? c
                          : const Center(child: CircularProgressIndicator()))),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton.icon(
                  onPressed: busy ? null : download,
                  icon: busy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download),
                  label: const Text('Download'),
                ),
              ),
            ),
          ),
        ]),
      );
}

class LogPage extends StatefulWidget {
  const LogPage({super.key});
  @override
  State<LogPage> createState() => _LogPageState();
}

class _LogPageState extends State<LogPage> {
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Error log'), actions: [
          IconButton(
            tooltip: 'Copy',
            icon: const Icon(Icons.copy),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: AppLog.text));
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Log copied')));
            },
          ),
          IconButton(
            tooltip: 'Clear',
            icon: const Icon(Icons.delete_outline),
            onPressed: () => setState(AppLog.clear),
          ),
        ]),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(14),
          child: SelectableText(AppLog.text,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
        ),
      );
}
