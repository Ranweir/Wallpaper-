import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;

// ====== SIRF YE EK LINE BADALNI HAI ======
// Apna GitHub username aur repo name daalo (branch: main)
const String baseUrl =
    'https://raw.githubusercontent.com/USERNAME/REPO/main/';
// =========================================

String resolve(String u) => u.startsWith('http') ? u : baseUrl + u;

void main() => runApp(const WallApp());

class WallApp extends StatelessWidget {
  const WallApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'My Wallpapers',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const HomePage(),
      );
}

class Wall {
  final String title, category, url, thumb;
  Wall(Map<String, dynamic> j)
      : title = j['title'] ?? '',
        category = j['category'] ?? '',
        url = resolve(j['url'] ?? ''),
        thumb = resolve(j['thumb'] ?? j['url'] ?? '');
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Wall> all = [];
  String cat = 'All', query = '';
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final r = await http.get(Uri.parse('${baseUrl}wallpapers.json'));
      if (r.statusCode != 200) throw 'HTTP ${r.statusCode}';
      final list = jsonDecode(utf8.decode(r.bodyBytes)) as List;
      all = list.map((e) => Wall(e)).toList();
    } catch (e) {
      error = 'wallpapers.json load nahi hui.\nbaseUrl check karo.\n($e)';
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final cats = ['All', ...{...all.map((w) => w.category).where((c) => c.isNotEmpty)}];
    final list = all
        .where((w) =>
            (cat == 'All' || w.category == cat) &&
            w.title.toLowerCase().contains(query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('My Wallpapers')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(error!, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: load, child: const Text('Retry')),
                ]))
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Search…',
                        prefixIcon: const Icon(Icons.search),
                        filled: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none),
                      ),
                      onChanged: (v) => setState(() => query = v),
                    ),
                  ),
                  SizedBox(
                    height: 52,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      children: cats
                          .map((c) => Padding(
                                padding: const EdgeInsets.all(6),
                                child: ChoiceChip(
                                  label: Text(c),
                                  selected: c == cat,
                                  onSelected: (_) => setState(() => cat = c),
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: load,
                      child: GridView.builder(
                        padding: const EdgeInsets.all(12),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10,
                                childAspectRatio: 9 / 16),
                        itemCount: list.length,
                        itemBuilder: (_, i) => GestureDetector(
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => PreviewPage(wall: list[i]))),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: Image.network(list[i].thumb,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const ColoredBox(
                                    color: Colors.black26,
                                    child: Icon(Icons.broken_image))),
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
    );
  }
}

class PreviewPage extends StatefulWidget {
  final Wall wall;
  const PreviewPage({super.key, required this.wall});
  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> {
  bool busy = false;

  Future<void> download() async {
    setState(() => busy = true);
    String msg;
    try {
      if (!await Gal.hasAccess()) await Gal.requestAccess();
      final r = await http.get(Uri.parse(widget.wall.url));
      if (r.statusCode != 200) throw 'HTTP ${r.statusCode}';
      await Gal.putImageBytes(r.bodyBytes, album: 'Wallpapers');
      msg = 'Gallery me save ho gayi (Wallpapers album)';
    } catch (e) {
      msg = 'Download fail: $e';
    }
    if (!mounted) return;
    setState(() => busy = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: Text(widget.wall.title)),
        body: Column(children: [
          Expanded(
            child: InteractiveViewer(
              child: Center(
                  child: Image.network(widget.wall.url,
                      loadingBuilder: (_, c, p) => p == null
                          ? c
                          : const Center(child: CircularProgressIndicator()))),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton.icon(
                  onPressed: busy ? null : download,
                  icon: busy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download),
                  label: const Text('Download'),
                ),
              ),
            ),
          ),
        ]),
      );
}
